create procedure myProcedure(IN stud_id int, OUT stud_name varchar(255), INOUT y int)
  firstBegin: begin
    declare a, b, c int default y;
#     select name from student where id = stud_id;
#     select name into stud_name from student where id = stud_id;
    select id - b into y from student where id = 5;
  end firstBegin;

