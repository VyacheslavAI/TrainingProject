create procedure test()
  begin
    declare i, j int default 0;

#     while i < 3 do
#     set i = i + 1;
#     set j = j + i;
#     end while;

#     myLoop: loop
#       set i = i + 1;
#       set j = i + j;
#       if i >= 3 then leave myLoop; end if;
#     end loop;

    repeat
      set i = i + 1;
      set j = j + i;
    until i >= 3 end repeat;

    select j;
  end;

