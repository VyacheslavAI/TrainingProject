create function myFunction()
  returns int
  begin
    return 5;
  end;

